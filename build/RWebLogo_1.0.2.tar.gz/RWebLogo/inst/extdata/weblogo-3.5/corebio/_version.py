__version__ = '3.5.0'

description = "CoreBio %s " % (__version__)
